import nltk

class Analyzer():
    """Implements sentiment analysis."""
    
    
    
    def __init__(self, positives="positive-words.txt", negatives="negative-words.txt"):
        """Initialize Analyzer."""

        file=open(positives,"r")
        positive=""
        while positive != "\n":
            positive=file.readline()
        
        positive=file.read()
        file.close()
        
        file=open(negatives,"r")
        negative=""
        while negative != "\n":
            negative=file.readline()
        
        negative=file.read()
        file.close()
        self.positive = positive.split("\n")
        self.negative = negative.split("\n")
        # TODO

    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""
        score = 0
        tokenizer = nltk.tokenize.TweetTokenizer()
        text=tokenizer.tokenize(text)
        for word in text:
            if word.lower() in self.positive:
                score = score + 1
            if word.lower() in self.negative:
                score = score - 1
            
        return score
