a="aaa\nbdjh\nciiu\n"
a=a.split("\n")
a=' '.join(a)
a=a.replace('d',' ')
print (a,len(a))